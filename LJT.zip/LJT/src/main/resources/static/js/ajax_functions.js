$(document).ready(function () {
		//alert("login");

	$("#login-form").submit(function (event) {
        // stop submit the form event. Do this manually using ajax post function
        event.preventDefault();
        var loginForm = {};
        //ﾕｰｻﾞ名取得
        loginForm.UserID = $("#UserID").val();
        var userID = $("#UserID").val();
    	//alert(loginForm["UserID"]);
    	// ﾎﾞﾀﾝ非活性
        $("#btn-login").prop("disabled", true);
        $.ajax({
            type: "POST",
            contentType: "application/json",
            url: "/post?UserID="+userID,
            //url: "/post"
            data: JSON.stringify(loginForm),
            //data: loginForm,
            dataType: 'text',
            cache: false,
            timeout: 600000,
            success: function (data,status,xhr) {
            	//alert("OK")
            	//xhr.getrequestHeader()
            	//window.location.href=data;
            	window.location.href=xhr.getResponseHeader("location");
            	
            	console.log("SUCCESS : ", data);
                // ﾎﾞﾀﾝ活性化
                $("#btn-login").prop("disabled", false);
               	return false;
            },
            error: function (e) {
                console.log("ERROR : ", e);
                $("#btn-login").prop("disabled", false);
            }
        });
    });
});