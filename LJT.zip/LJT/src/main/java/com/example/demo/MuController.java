//package com.example.demo;
//import java.util.HashMap;
//import java.util.Map;
//
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpSession;
//
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//
//
//
//@Controller
//public class MuController {
//	
//	@GetMapping({"login","/"})
//	public String index(Model model, HttpServletRequest request) {
//		
//		Map userMap = new HashMap();
//		//　ログインユーザ
//		userMap.put("key1","User01");
//		userMap.put("key2","User02");
//		userMap.put("key3","User03");
//		model.addAttribute("userMap", userMap);
//
//		HttpSession session =request.getSession();
//		Object loginUserId = session.getAttribute("UserID");
//		
//		if (loginUserId == null) {
//			//存在しないの場合　ログイン画面
//			return "showMessage";
//		} else
//		{
//			//Session存在の場合
//			//　成功画面に遷移(JSPファイル)
//			model.addAttribute("userid",loginUserId.toString());
//			return "index";
//		}
//	}
//
//	@RequestMapping(path = "/post", method = RequestMethod.POST)
//	public String Display(Model model, HttpServletRequest request) {
//
//		String userID = request.getParameter("UserID");
//		//System.out.print(userID);
//		HttpSession session =request.getSession();
//		Object loginUserId = session.getAttribute(userID);
//		session.setAttribute("UserID", userID);
//		model.addAttribute("userid",userID);
//		return "index";
//	} 
//}




package com.example.demo;
import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;



@Controller
@PropertySource(value = {"classpath:PageBeans.properties"})
public class MuController {

	@Value("${IndexUri}")
	private String IndexUri;

	
	//@GetMapping(value="/login/*/*/*/aaa")
	//@GetMapping(value="/**/login")
	//@GetMapping(value="/*/login")
	@GetMapping(value="/login/**")
	public String index(Model model, HttpServletRequest request,@PathVariable(required=false,value="path") String path) {
		
		System.out.println(path);
		Map userMap = new HashMap();
		//　ログインユーザ
		userMap.put("key1","User01");
		userMap.put("key2","User02");
		userMap.put("key3","User03");
		model.addAttribute("userMap", userMap);

		HttpSession session =request.getSession();
		Object loginUserId = session.getAttribute("UserID");
		

		if (loginUserId == null) {
			//存在しないの場合　ログイン画面
			return "Login";
		} else
		{
			//Session存在の場合
			//　成功画面に遷移(JSPファイル)
			//model.addAttribute("userid",loginUserId.toString());
			//return "redirect:Login-Success.html?UserID="+loginUserId.toString();
			String uri = IndexUri + "?UserID="+loginUserId.toString();
			return "redirect:"+uri;
		}
	}
	
	

	@RequestMapping(path = "/post", method = RequestMethod.POST)
	public ResponseEntity<String> DisplayByURI(Model model, HttpServletRequest request) {

		String userID = request.getParameter("UserID");
		//System.out.print(userID);
		HttpSession session =request.getSession();
		Object loginUserId = session.getAttribute(userID);
		session.setAttribute("UserID", userID);
		model.addAttribute("userid",userID);
		String uri = IndexUri + "?UserID="+userID;
		//System.out.println(IndexUri);
		return ResponseEntity.created(URI.create(uri)).build();
		//return ResponseEntity.ok(uri);
	} 
}